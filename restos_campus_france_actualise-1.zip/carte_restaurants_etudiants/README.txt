RESTOS CAMPUS FRANCE — INSTALLATION

1. Décompressez l'archive ZIP.
2. Publiez index.html et donnees.xlsx dans le même dossier sur un hébergement web statique HTTPS (Netlify, GitHub Pages, OVH, etc.).
3. Ouvrez l'adresse du site publiée.
4. Pour actualiser les données, remplacez donnees.xlsx ou utilisez le bouton d'import de fichier Excel sur la page.

STRUCTURE ATTENDUE DU CLASSEUR
Onglet « Etablissements » : Établissement, Ville, Code postal, Adresse, Latitude, Longitude.
Onglet « Restaurants » : Restaurant, Ville, Catégorie, Code postal, Adresse, Latitude, Longitude, Prix indicatif (€), Tarif étudiant.

IMPORTANT
Le classeur fourni est une trame vide. Aucun restaurant ou établissement n'est inventé.
L'application n'effectue pas automatiquement la collecte nationale des données.
Les recherches par ville/code postal utilisent geo.api.gouv.fr ; carte OpenStreetMap via Leaflet.
La distance affichée est à vol d'oiseau, et non un trajet à pied.
Les prix inconnus sont exclus lorsque le filtre budget est actif.
Pour une mise à jour en ligne centralisée sans remplacer le fichier, il faudra ajouter un backend ou un service de synchronisation.

VERSION RECHERCHE EN LIGNE (octobre 2026)
Après sélection d'une ville, le site tente de consulter les API publiques de l'annuaire scolaire, des lieux CROUS et OpenStreetMap (Overpass). Ces flux peuvent être temporairement indisponibles ou limiter les requêtes. Le fichier Excel reste importable et peut être modifié indépendamment.
Les tarifs et remises ne sont pas déduits automatiquement : « à vérifier » n'est pas une réduction confirmée. Le résultat n'est pas une base nationale exhaustive. Pour le publier, déposer les fichiers sur un hébergement statique HTTPS. Ouvrir via un serveur web (pas file://).
